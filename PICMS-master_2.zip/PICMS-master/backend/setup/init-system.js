require("dotenv").config();
const axios = require("axios");
const { v4: uuidv4 } = require("uuid");

const API_BASE_URL = process.env.API_BASE_URL || "http://localhost:4500/api/v1";
const api = axios.create({ baseURL: API_BASE_URL });

let store = {};

async function initSystem() {
  console.log("Starting system initialization...");
  try {
    // Initialize store
    store = {};

    // 1. Create essential modules
    console.log("\n1. Creating modules...");
    const modules = await createModules();
    store.modules = modules;

    // 2. Create roles
    console.log("\n2. Creating roles...");
    const roles = await createRoles();
    store.roles = roles;

    // 3. Create basic data
    console.log("\n3. Creating basic data...");
    const { genders, statuses } = await createBasicData();
    store.genders = genders;
    store.statuses = statuses;

    // 4. Set up permissions
    console.log("\n4. Setting up permissions...");
    await setupPermissions(store.roles, store.modules);

    // 5. Create initial configurations
    console.log("\n5. Creating initial configurations...");
    await createInitialConfigs();

    // 6. Create admin user
    console.log("\n6. Creating admin user...");
    await createAdminUser(store);

    // 7. Create claims adjuster user
    console.log("\n7. Creating claims adjuster user...");
    await createClaimsAdjusterUser(store);

    // 8. Create policy holder users
    console.log("\n8. Creating policy holder users...");
    const policyHolders = await createPolicyHolderUsers(store);
    store.policyHolders = policyHolders;

    // 9. Create sample data (policies, claims, payments)
    console.log("\n9. Creating sample policies, claims and payments...");
    await createSampleData(store);

    console.log("\nSystem initialization completed successfully!");
    console.log("\nCreated references:", JSON.stringify(store, null, 2));
  } catch (error) {
    console.error("Initialization failed:", error.message);
    if (error.response) {
      console.error("API Response:", error.response.data);
    }
    process.exit(1);
  }
}
async function createClaimsAdjusterUser(store) {
  const currentDate = new Date().toISOString().split("T")[0];
  const adjusterUser = {
    fullname: "Claims Adjuster",
    email: process.env.ADJUSTER_EMAIL || "adjuster@prime.com",
    password: process.env.ADJUSTER_PASSWORD || "Adjuster123!",
    phoneNumber: "+1234567891",
    dateOfBirth: "1990-01-01",
    recruitmentDate: currentDate,
    role: store.roles["Claims Adjuster"]._id,
    status: store.statuses["Active"],
    gender: store.genders["Male"],
    isAccountActive:true,
    description: "Claims Adjuster User",
  };

  try {
    await api.post("/users/register", adjusterUser);
    console.log("✓ Created claims adjuster user");
  } catch (error) {
    console.error(
      "Failed to create claims adjuster:",
      error.response?.data || error.message
    );
    throw error;
  }
}

async function createPolicyHolderUsers(store) {
  const currentDate = new Date().toISOString().split("T")[0];
  const policyHolders = [
    {
      fullname: "John Banda",
      email: process.env.POLICY_HOLDER_EMAIL1 || "john@prime.com",
      password: process.env.POLICY_HOLDER_PASSWORD1 || "Password123!",
      phoneNumber: "+1234567891",
      dateOfBirth: "1990-01-01",
      registrationDate: currentDate,
      role: store.roles["Policy Holder"]._id,
      status: store.statuses["Active"],
      gender: store.genders["Male"],
      isAccountActive:true,
      description: "Sample policy holder",
    },
    {
      fullname: "Jane phiri",
      email: process.env.POLICY_HOLDER_EMAIL2 || "jane@prime.com",
      password: process.env.POLICY_HOLDER_PASSWORD2 || "Password123!",
      phoneNumber: "+1234567892",
      dateOfBirth: "1992-01-01",
      registrationDate: currentDate,
      role: store.roles["Policy Holder"]._id,
      status: store.statuses["Active"],
      gender: store.genders["Female"],
      isAccountActive:true,
      description: "Sample policy holder",
    },
  ];

  const createdPolicyHolders = [];
  for (const user of policyHolders) {
    try {
      const response = await api.post("/users/register", user);
      createdPolicyHolders.push(response.data);
      console.log(`✓ Created policy holder: ${user.fullname}`);
    } catch (error) {
      console.error(
        `Failed to create policy holder ${user.fullname}:`,
        error.response?.data || error.message
      );
      throw error;
    }
  }
  return createdPolicyHolders;
}

async function createSampleData(store) {
  try {
    const currentDate = new Date().toISOString().split("T")[0];

    // Create sample policies
    const policies = [
      {
        policyNumber: `POL-${uuidv4().split("-")[0]}`,
        policyName: "Comprehensive Auto Insurance",
        premium: 1200,
        status: "active",
        startDate: currentDate,
        endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1))
          .toISOString()
          .split("T")[0],
        description: "Full coverage auto insurance policy",
      },
      {
        policyNumber: `POL-${uuidv4().split("-")[0]}`,
        policyName: "Basic Health Insurance",
        premium: 2400,
        status: "active",
        startDate: currentDate,
        endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1))
          .toISOString()
          .split("T")[0],
        description: "Basic health coverage policy",
      },
    ];

    const createdPolicies = [];
    for (const policy of policies) {
      try {
        const response = await api.post("/policies", policy);
        createdPolicies.push(response.data);
        console.log(`✓ Created policy: ${policy.policyName}`);
      } catch (error) {
        console.error(
          "Failed to create policy:",
          error.response?.data || error.message
        );
      }
    }

    // Create sample claims using stored policy holders
    if (
      store.policyHolders &&
      store.policyHolders.length > 0 &&
      createdPolicies.length > 0
    ) {
      const claims = [
        {
          claimNumber: `CLM-${uuidv4().split("-")[0]}`,
          policy: createdPolicies[0]._id,
          claimant: store.policyHolders[0]._id,
          incidentDate: "2024-03-01",
          filingDate: "2024-03-02",
          description: "Car accident on highway",
          claimedAmount: 5000,
          status: "submitted",
        },
        {
          claimNumber: `CLM-${uuidv4().split("-")[0]}`,
          policy: createdPolicies[1]._id,
          claimant: store.policyHolders[1]._id,
          incidentDate: "2024-03-10",
          filingDate: "2024-03-11",
          description: "Hospital admission for surgery",
          claimedAmount: 8000,
          status: "under_review",
        },
      ];

      for (const claim of claims) {
        try {
          await api.post("/claims", claim);
          console.log(`✓ Created claim: ${claim.claimNumber}`);
        } catch (error) {
          console.error(
            "Failed to create claim:",
            error.response?.data || error.message
          );
        }
      }


    }
  } catch (error) {
    console.error(
      "Failed to create sample data:",
      error.response?.data || error.message
    );
    throw error;
  }
}

async function createRoles() {
  const roles = [
    {
      roleName: "Admin",
      description: "System Administrator with full access",
    },
    {
      roleName: "Claims Adjuster",
      description: "Manages claims and policies",
    },
    {
      roleName: "Policy Holder",
      description: "Regular user with limited access",
    },
  ];

  const createdRoles = {};
  for (const role of roles) {
    const response = await api.post("/roles", role);
    createdRoles[role.roleName] = response.data;
    console.log(`✓ Created ${role.roleName} role`);
  }
  return createdRoles;
}

async function createModules() {
  const modulesList = [
    "genders",
    "staff-statuses",
    "roles",
    "modules",
    "permissions",
    "users",
    "system-logs",
    "system-config",
    "company-config",
    "claims",
    "policies",
    "my-claims",
    "policy-holders",
    "subscription",
    "payments",
    "reports",
    "notifications",
  ];

  const modules = {};
  for (const moduleName of modulesList) {
    const response = await api.post("/modules", {
      moduleName,
      description: getModuleDescription(moduleName),
    });
    modules[moduleName] = response.data._id;
    console.log(`✓ Created module: ${moduleName}`);
  }
  return modules;
}

function getModuleDescription(moduleName) {
  const descriptions = {
    claims: "Manage insurance claims",
    policies: "Manage insurance policies",
    "my-claims": "View and manage personal claims",
    "policy-holders": "Manage policy holders",
    subscription: "Manage subscription plans",
    payments: "Handle payment transactions",
    reports: "Generate and view reports",
    notifications: "System notifications",
    genders: "Gender management module",
    "staff-statuses": "Staff statuses management module",
    roles: "Roles management module",
    modules: "Modules management module",
    permissions: "Permissions management module",
    users: "Users management module",
    "system-logs": "System logs management module",
    "system-config": "System configuration module",
    "company-config": "Company configuration module",
  };

  return descriptions[moduleName] || `${moduleName} management module`;
}

async function setupPermissions(roles, modules) {
  const permissionsMap = {
    Admin: Object.keys(modules),
    "Claims Adjuster": [
      "claims",
      "policies",
      "reports",
      "notifications",
      "policy-holders",
    ],
    "Policy Holder": ["my-claims", "subscription", "payments", "notifications"],
  };

  for (const [roleName, allowedModules] of Object.entries(permissionsMap)) {
    const roleId = roles[roleName]._id;

    for (const moduleName of allowedModules) {
      const moduleId = modules[moduleName];
      await api.post("/permissions", {
        role: roleId,
        module: moduleId,
        create: true,
        read: true,
        update: true,
        delete: roleName === "Admin",
      });
      console.log(`✓ Created permissions for ${roleName} - ${moduleName}`);
    }
  }
}

async function createBasicData() {
  const genders = {};
  const gendersList = ["Male", "Female"];
  for (const gender of gendersList) {
    const response = await api.post("/genders", {
      gender,
      description: `${gender} gender`,
    });
    genders[gender] = response.data._id;
    console.log(`✓ Created gender: ${gender}`);
  }

  const statuses = {};
  const statusesList = ["Active", "Inactive"];
  for (const status of statusesList) {
    const response = await api.post("/staff-statuses", {
      status,
      description: `${status} status`,
    });
    statuses[status] = response.data._id;
    console.log(`✓ Created status: ${status}`);
  }

  return { genders, statuses };
}

async function createInitialConfigs() {
  const systemConfig = {
    logo:
      process.env.LOGO_URL ||
      "https://firebasestorage.googleapis.com/v0/b/server-services-50a49.appspot.com/o/logo%2FScreenshot_20240909_032140-removebg-preview.png?alt=media&token=f7739e91-f075-43e9-bf69-1518217d53b8",
    appName: process.env.APP_NAME || "System factory",
    appVersion: "1.0.0",
    appLanguage: "en",
    loginPageLayout: "DefaultLayout",
    maintenanceMode: false,
    appDescription: "Initial system setup",
    maintenanceMessage: "System is under maintenance",
  };

  await api.post("/system-config", systemConfig);
  console.log("✓ Created system configuration");

  const companyConfig = {
    companyName: process.env.COMPANY_NAME || "My Company",
    companyAddress: "Company Address",
    companyLocation: "Company Location",
    companyMotto: "Company Motto",
    companyEmails: [
      {
        name: "Info",
        email: process.env.COMPANY_EMAIL || "info@companyzzz.com",
      },
    ],
    companyPhoneNumbers: [
      {
        name: "Main",
        phoneNumber: process.env.COMPANY_PHONE || "+1234567890",
      },
    ],
  };

  await api.post("/company-config", companyConfig);
  console.log("✓ Created company configuration");
}

async function createAdminUser(store) {
  const currentDate = new Date().toISOString().split("T")[0];
  const adminUser = {
    fullname: "Administrator",
    email: process.env.ADMIN_EMAIL || "admin@prime.com",
    password: process.env.ADMIN_PASSWORD || "Admin123!",
    phoneNumber: "+1234567890",
    dateOfBirth: "1990-01-01",
    recruitmentDate: currentDate,
    role: store.roles["Admin"]._id,
    status: store.statuses["Active"],
    gender: store.genders["Male"],
    isAccountActive:true,
    description: "System Administrator",
  };

  try {
    await api.post("/users/register", adminUser);
    console.log("✓ Created admin user");
  } catch (error) {
    console.error(
      "Failed to create admin user:",
      error.response?.data || error.message
    );
    throw error;
  }
}

initSystem();
