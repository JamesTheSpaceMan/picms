import { Resources as AdminResources } from "./resources";
import { website_config } from "../modules/e_commerce_system/website";


export const systemConfig = {
  name: "system-factory",
  defaultUrl: "/login",
  portals: [
    {
      name: "website",
      url: "/home",
      type: "web",
      icon: "fa fa-home",
      resources: website_config,
    },
    {
      name: "admin",
      url: "/dashboard",
      type: "drawer",
      icon: "fa fa-home",
      resources: AdminResources,
    },


  ],
};
