import { system_settings } from "../modules/system_settings/system_settings";
import { e_commerce_management_system } from "../modules/e_commerce_system/system";
import { user_management_system } from "../modules/user_management_system/system";
import { insurance_claims_management_system } from "../modules/insurance_claims_management_system/system";
import { chat_system } from "../modules/chat_system/chat_system";
export const Resources = [
...user_management_system,
...insurance_claims_management_system,
...system_settings,
...chat_system,
];
