export const website_config =[
  {
    "name": "",
    "path": "",
    "icon": "fa fa-home",
    "label": "Home",
    "renderMode": "webpage",
    "widgets": [
      {
        "type": "hero-carousel",
        "props": {
          "carouselItems": [
            {
              "title": "Welcome to Prime Insurance",
              "subtitle": "Protecting What Matters Most",
              "description": "Comprehensive insurance solutions tailored to your needs, providing peace of mind for you and your loved ones.",
              "imageUrl": "https://images.pexels.com/photos/3823488/pexels-photo-3823488.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
              "imageAlt": "Prime Insurance Protection",
              "button": {
                "label": "Get a Quote",
                "link": "/home/quote",
                "icon": "fa fa-calculator"
              }
            },
            {
              "title": "Discover Our Coverage Options",
              "subtitle": "Tailored Insurance Plans for Every Stage of Life",
              "description": "From health and life insurance to property and auto coverage, we've got you protected.",
              "imageUrl": "https://images.pexels.com/photos/7648467/pexels-photo-7648467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
              "imageAlt": "Insurance Coverage Options",
              "button": {
                "label": "Explore Plans",
                "link": "/home/plans",
                "icon": "fa fa-shield-alt"
              }
            },
            {
              "title": "Start Your Protection Journey",
              "subtitle": "Secure Your Future Today",
              "description": "Create an account and discover how we can safeguard what's important to you.",
              "imageUrl": "https://images.pexels.com/photos/7176026/pexels-photo-7176026.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
              "imageAlt": "Start Your Insurance Journey",
              "button": {
                "label": "Join Now",
                "link": "/login",
                "icon": "fa fa-user-plus"
              }
            }
          ],
          "layout": "center"
        }
      },
      {
        "type": "features",
        "props": {
          "title": "Why Choose Prime Insurance?",
          "features": [
            {
              "title": "Fast Claims Processing",
              "description": "Get your claims processed within 48 hours.",
              "icon": "fa fa-bolt"
            },
            {
              "title": "24/7 Customer Support",
              "description": "Round-the-clock assistance for all your insurance needs.",
              "icon": "fa fa-headset"
            },
            {
              "title": "Customizable Policies",
              "description": "Tailor your coverage to fit your unique requirements.",
              "icon": "fa fa-sliders-h"
            }
          ]
        }
      },
      {
        "type": "stats",
        "props": {
          "title": "Prime Insurance by the Numbers",
          "stats": [
            {
              "value": "1M+",
              "label": "Satisfied Customers",
              "icon": "fa fa-users"
            },
            {
              "value": "MK50M+",
              "label": "Claims Paid",
              "icon": "fa fa-dollar-sign"
            },
            {
              "value": "99%",
              "label": "Customer Satisfaction",
              "icon": "fa fa-smile"
            }
          ]
        }
      },
      {
        "type": "testimonial",
        "props": {
          "quote": "Prime Insurance has given me peace of mind knowing my family is protected. Their customer service is exceptional!",
          "author": "Sarah Banda",
          "position": "Satisfied Customer",
          "imageUrl": "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
        }
      },
      {
        "type": "cta",
        "props": {
          "title": "Get Protected Today",
          "description": "Start your journey to a more secure future with our tailored insurance plans.",
          "button": {
            "label": "Get a Quote",
            "link": "/quote",
            "icon": "fa fa-calculator"
          },
          "backgroundColor": "#f0f4f8"
        }
      }
    ]
  },
  {
    "name": "plans",
    "path": "plans",
    "icon": "fa fa-shield-alt",
    "label": "Our Plans",
    "renderMode": "webpage",
    "widgets": [
      {
        "type": "hero",
        "props": {
          "title": "Choose Your Insurance Plan",
          "subtitle": "Secure Your Future Today",
          "description": "Tailored Insurance Plans for Every Stage of Life",
          "imageUrl": "https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
          "button": {
            "label": "Get a Quote",
            "link": "/quote",
            "icon": "fa fa-calculator"
          }
        }
      },
      {
        "type": "pricing",
        "props": {
          "title": "Choose Your Protection Plan",
          "description": "Find the perfect coverage that fits your needs and budget.",
          "plans": [
            {
              "name": "Basic Protection",
              "price": "MK10029.99",
              "period": "/month",
              "features": [
                "Life Insurance Coverage",
                "Accident Protection",
                "24/7 Customer Support"
              ],
              "button": {
                "label": "Get Started",
                "link": "/quote/basic"
              },
              "highlighted": false
            },
            {
              "name": "Premium Coverage",
              "price": "MK9000.99",
              "period": "/month",
              "features": [
                "Enhanced Life Insurance",
                "Health Insurance",
                "Property Protection",
                "Priority Claims Processing"
              ],
              "button": {
                "label": "Choose Plan",
                "link": "/quote/premium"
              },
              "highlighted": true
            },
            {
              "name": "Family Shield",
              "price": "MK85000.99",
              "period": "/month",
              "features": [
                "Comprehensive Family Coverage",
                "Education Protection",
                "Retirement Planning",
                "Exclusive Benefits"
              ],
              "button": {
                "label": "Protect Your Family",
                "link": "/quote/family"
              },
              "highlighted": false
            }
          ]
        }
      }
    ]
  },
  {
    "name": "about-us",
    "path": "about-us",
    "icon": "fa fa-info-circle",
    "label": "About Us",
    "renderMode": "webpage",
    "widgets": [
      {
        "type": "hero",
        "props": {
          "title": "About Us",
          "subtitle": "We are a family-owned insurance company with over 10 years of experience.",
          "imageUrl": "https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
          "description": "Learn more about our company and our mission.",
          "button": {
            "label": "Learn More",
            "link": "/about-us"
          }
        }
      },
      {
        "type": "timeline",
        "props": {
          "title": "Our Journey",
          "events": [
            {
              "year": "1990",
              "title": "Founded",
              "description": "Prime Insurance was established with a mission to protect families."
            },
            {
              "year": "2000",
              "title": "Expansion",
              "description": "We expanded our services nationwide, reaching more customers."
            },
            {
              "year": "2010",
              "title": "Digital Transformation",
              "description": "Launched our online platform for easier policy management and claims."
            },
            {
              "year": "2020",
              "title": "Innovation",
              "description": "Introduced AI-driven risk assessment for personalized coverage."
            }
          ]
        }
      },
    ]
  },
  {
    "name": "contact-us",
    "path": "contact-us",
    "icon": "fa fa-phone",
    "label": "Contact Us",
    "renderMode": "webpage",
    "widgets": [
      {
        "type": "faq",
        "props": {
          "title": "Frequently Asked Questions",
          "questions": [
            {
              "question": "How do I file a claim?",
              "answer": "You can file a claim through our online portal or by calling our 24/7 claims hotline."
            },
            {
              "question": "What types of insurance do you offer?",
              "answer": "We offer a wide range of insurance products including life, health, property, and auto insurance."
            },
            {
              "question": "How can I get a quote?",
              "answer": "You can get a personalized quote by using our online quote tool or by speaking with one of our insurance agents."
            }
          ]
        }
      },
      {
        "type": "cta",
        "props": {
          "title": "Need More Information?",
          "description": "Our insurance experts are here to help you find the right coverage.",
          "button": {
            "label": "Contact an Agent",
            "link": "/contact-us/agent",
            "icon": "fa fa-user-tie"
          }
        }
      }
    ]
  },


]