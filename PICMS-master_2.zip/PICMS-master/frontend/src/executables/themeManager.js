// themeManager.js
import { ref, watch } from "vue";

const activeTheme = ref("default");
const customThemes = ref({});

const Light = {
  text: "#2C3E50",
  textLight: "#F9F9F9",
  textLighter: "#FFFFFF",
  textDark: "#34495E",
  textDarker: "#2A2A2A",
  cardLight: "#ffffff",
  cardDark: "#f0f0f0",
  background: "#e0e0e0",
  primary: "#3498db",
  secondary: "#2e9acc",
  tertiary: "#e74c3c",
  menubg: "#2C3E50",
  backgroundHover: "#2980b9",
  webPrimary: "#3498db",
  webSecondary: "#2e85cc",
  webBackground: "#FFFFFF",
  webBackgroundDark: "#2F2F2F",
  webPrimaryHover: "#2980b9",
  webSecondaryHover: "#2795ae",
  webBackgroundHover: "#EAEAEA",
  webBackgroundDarkHover: "#222222",
};

const premadeThemes = {
  Light: Light,
  Dark: {
    text: "#F9F9F9",
    textLight: "#FFFFFF",
    textLighter: "#F0F0F0",
    textDark: "#E0E0E0",
    textDarker: "#C7C7C7",
    cardLight: "#2F2F2F",
    cardDark: "#222222",
    background: "#2A2A2A",
    primary: "#3498db",
    secondary: "#2e85cc",
    tertiary: "#e74c3c",
    menubg: "#1F2C3A",
    backgroundHover: "#3498db",
    webPrimary: "#3498db",
    webSecondary: "#2e85cc",
    webBackground: "#2F2F2F",
    webBackgroundDark: "#1A1A1A",
    webPrimaryHover: "#2980b9",
    webSecondaryHover: "#2795ae",
    webBackgroundHover: "#1E1E1E",
    webBackgroundDarkHover: "#151515",
  },
};

export function useThemeManager() {
  function setTheme(themeName) {
    activeTheme.value = themeName;
    applyTheme(themeName);
  }

  function addCustomTheme(name, colors) {
    customThemes.value[name] = colors;
  }

  function applyTheme(themeName) {
    let theme = premadeThemes[themeName] || Light;
    Object.entries(theme).forEach(([key, value]) => {
      document.documentElement.style.setProperty(`--${key}`, value);
    });
  }

  function saveThemesToStorage() {
    localStorage.setItem("customThemes", JSON.stringify(customThemes.value));
    localStorage.setItem("activeTheme", activeTheme.value);
  }

  function loadThemesFromStorage() {
    const storedThemes = localStorage.getItem("customThemes");
    if (storedThemes) {
      customThemes.value = JSON.parse(storedThemes);
    }

    const storedActiveTheme = localStorage.getItem("activeTheme");
    if (storedActiveTheme) {
      setTheme(storedActiveTheme);
    } else {
      setTheme("default");
    }
  }

  function removeCustomTheme(themeName) {
    if (customThemes.value[themeName]) {
      delete customThemes.value[themeName];
      if (activeTheme.value === themeName) {
        setTheme("default");
      }
    }
  }

  function getThemeNames() {
    return [
      "default",
      ...Object.keys(premadeThemes),
      ...Object.keys(customThemes.value),
    ];
  }

  function getThemeColors(themeName) {
    if (themeName === "default") {
      return Light;
    } else if (premadeThemes[themeName]) {
      return premadeThemes[themeName];
    } else {
      return customThemes.value[themeName];
    }
  }

  // Watch for changes in customThemes and activeTheme
  watch(customThemes, saveThemesToStorage, { deep: true });
  watch(activeTheme, saveThemesToStorage);

  // Initial load from storage
  loadThemesFromStorage();

  return {
    activeTheme,
    customThemes,
    setTheme,
    addCustomTheme,
    removeCustomTheme,
    getThemeNames,
    getThemeColors,
    Light,
    premadeThemes,
  };
}
