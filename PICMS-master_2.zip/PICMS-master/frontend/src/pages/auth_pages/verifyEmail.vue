<!-- src/views/VerifyEmail.vue -->
<script setup>
import { ref, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import axios from 'axios';

const router = useRouter();
const route = useRoute();
const loading = ref(true);
const verified = ref(false);
const error = ref('');

async function verifyEmail() {
  try {
    const email = route.query.email;
    const token = route.query.token;
    
    if (!email || !token) {
      throw new Error('Invalid verification link');
    }

    // Get the stored registration data
    const pendingRegistration = JSON.parse(localStorage.getItem('pendingRegistration'));
    
    if (!pendingRegistration) {
      throw new Error('Registration data not found');
    }

    // Complete the registration
    const response = await axios.post(
      `${import.meta.env.VITE_APP_API_URL}/api/v1/users/register`,
      {
        ...pendingRegistration,
        isAccountActive: true
      }
    );

    verified.value = true;
    localStorage.removeItem('pendingRegistration');
    
    // Redirect to login after 3 seconds
    setTimeout(() => {
      router.push('/login');
    }, 3000);

  } catch (err) {
    error.value = err.message || 'Verification failed';
  } finally {
    loading.value = false;
  }
}

onMounted(() => {
  verifyEmail();
});
</script>

<template>
  <div class="h-screen flex items-center justify-center bg-primary">
    <div class="bg-white p-8 rounded-lg shadow-lg text-center">
      <h1 class="text-2xl font-bold mb-4">Email Verification</h1>
      
      <div v-if="loading" class="mb-4">
        Verifying your email...
      </div>
      
      <div v-else-if="verified" class="text-green-600 mb-4">
        Email verified successfully! Redirecting to login...
      </div>
      
      <div v-else-if="error" class="text-red-600 mb-4">
        {{ error }}
      </div>
    </div>
  </div>
</template>