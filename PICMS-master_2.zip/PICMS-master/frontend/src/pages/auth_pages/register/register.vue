<script setup>
import { ref, reactive, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import SfLoader from '../../../components/u_i/sf_loader.vue';
import SfLogo from '../../../components/u_i/sf_logo.vue';
import axios from 'axios';
import * as Yup from 'yup';

const router = useRouter();
const loading = ref(false);
const alertMessage = ref('');
const alertType = ref('');
const defaultRole = ref(null);
const formData = reactive({
  fullname: '',
  email: '',
  password: '',
  phoneNumber: '',
  dateOfBirth: '',
});
const verificationSent = ref(false);

const validationSchema = Yup.object().shape({
  fullname: Yup.string().required('Full name is required'),
  email: Yup.string().email('Invalid email').required('Email is required'),
  password: Yup.string().min(8, 'Password must be at least 8 characters').required('Password is required'),
  phoneNumber: Yup.string().matches(/^\d{10}$/, 'Phone number must be 10 digits').required('Phone number is required'),
  dateOfBirth: Yup.date().required('Date of birth is required'),
});

const getRoleId = async () => {
  const res = await axios.get(`${import.meta.env.VITE_APP_API_URL}/api/v1/roles?filter[roleName]=Policy%20Holder`);
  defaultRole.value = res.data.data[0].id;
};

async function sendVerificationEmail(email) {
  try {
    await axios.post(`${import.meta.env.VITE_APP_API_URL}/sendEmail`, {
      subject: 'Email Verification',
      recipientEmail: email,
      message: `Please verify your email by clicking this link:<a href='http://localhost:5173/verify-email?email=${email}&token=${generateVerificationToken()}'> http://localhost:5173/verify-email?email=${email}&token=${generateVerificationToken()}</a>`,
      Logo: 'https://firebasestorage.googleapis.com/v0/b/server-services-50a49.appspot.com/o/logo%2FScreenshot_20240909_032140-removebg-preview.png?alt=media&token=f7739e91-f075-43e9-bf69-1518217d53b8'
    });
    return true;
  } catch (error) {
    console.error('Error sending verification email:', error);
    return false;
  }
}

function generateVerificationToken() {
  // Generate a random token for email verification
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

async function handleRegister() {
  try {
    loading.value = true;
    alertMessage.value = '';
    
    // Validate form data
    await validationSchema.validate(formData);
    
    // Send verification email first
    const emailSent = await sendVerificationEmail(formData.email);
    
    if (emailSent) {
      verificationSent.value = true;
      alertMessage.value = 'Please check your email for verification link';
      alertType.value = 'success';
      
      // Store user data temporarily (you might want to use Vuex or another state management solution)
      localStorage.setItem('pendingRegistration', JSON.stringify({
        ...formData,
        role: defaultRole.value,
        status: '66de57ce6c99dcbaeae904f2',
        isAccountActive: false
      }));
    } else {
      throw new Error('Failed to send verification email');
    }
  } catch (error) {
    alertMessage.value = error.message;
    alertType.value = 'error';
  } finally {
    loading.value = false;
  }
}

onMounted(async () => {
  await getRoleId();
});
</script>

<template>
  <div class="h-screen bg-primary flex flex-col md:flex-row">
    <div class="w-full max-w-md mx-auto flex flex-col justify-center items-center p-6">
      <div class="w-16 my-8">
        <SfLogo class="mx-auto" />
        <h1 class="text-white text-2xl font-bold">Register</h1>
      </div>
      
      <div v-if="alertMessage" :class="['alert', alertType === 'success' ? 'alert-success' : 'alert-error']">
        {{ alertMessage }}
      </div>

      <SfLoader v-if="loading" />
      
      <form v-else @submit.prevent="handleRegister" class="w-full space-y-4 bg-white p-6 rounded-lg">
        <div class="form-control">
          <label class="label">Full Name</label>
          <input v-model="formData.fullname" type="text" class="input input-bordered" required />
        </div>

        <div class="form-control">
          <label class="label">Email</label>
          <input v-model="formData.email" type="email" class="input input-bordered" required />
        </div>

        <div class="form-control">
          <label class="label">Password</label>
          <input v-model="formData.password" type="password" class="input input-bordered" required />
        </div>

        <div class="form-control">
          <label class="label">Phone Number</label>
          <input v-model="formData.phoneNumber" type="tel" class="input input-bordered" required />
        </div>

        <div class="form-control">
          <label class="label">Date of Birth</label>
          <input v-model="formData.dateOfBirth" type="date" class="input input-bordered" required />
        </div>

        <button type="submit" class="btn btn-primary w-full" :disabled="loading || verificationSent">
          {{ verificationSent ? 'Verification Email Sent' : 'Register' }}
        </button>

        <p class="text-center mt-4">
          Already have an account?
          <router-link to="/login" class="text-primary">Login</router-link>
        </p>
      </form>
    </div>
  </div>
</template>

<style scoped>
.alert {
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
  font-weight: bold;
}

.alert-success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.alert-error {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

.form-control {
  margin-bottom: 1rem;
}

.input {
  width: 100%;
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 0.25rem;
}

.btn {
  padding: 0.5rem 1rem;
  border-radius: 0.25rem;
  cursor: pointer;
}

.btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}
</style>