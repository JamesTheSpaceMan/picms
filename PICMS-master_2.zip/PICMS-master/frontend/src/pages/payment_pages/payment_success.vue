<template>
  <div class="bg-background min-h-screen flex items-center justify-center">
    <div v-if="loading" class="animate-pulse">
      <div class="w-16 h-16 border-4 border-secondary border-t-transparent rounded-full animate-spin"></div>
    </div>
    <div v-else class="bg-cardLight p-8 rounded-lg shadow-md max-w-md mx-auto transform transition-all duration-500 ease-in-out" :class="{ 'scale-0': !showContent, 'scale-100': showContent }">
      <div class="flex items-center justify-center mb-6">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          class="h-16 w-16 text-green-500 animate-bounce"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="2"
            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      </div>
      <h1 class="text-2xl font-bold text-center mb-4 animate-fade-in-down">Payment Successful</h1>
      <div class="mt-8 flex justify-center">
        <RouterLink to="/dashboard/payments"
          class="bg-secondary hover:bg-tertiary text-white font-bold py-2 px-4 rounded transition-all duration-300 ease-in-out transform hover:scale-105"
        >
          Go to Payments
        </RouterLink>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      loading: true,
      showContent: false,
      payment: {},
    };
  },
  mounted() {
    this.fetchPaymentDetails();
  },
  methods: {
    fetchPaymentDetails() {
      const sessionId = this.$route.query.session_id;
      if (!sessionId) {
        this.loading = false;
        this.showContent = true;
        return;
      }

      axios.get(`${import.meta.env.VITE_APP_API_URL}/api/v1/payment-details/${sessionId}`)
        .then(response => {
          this.payment = response.data;
        })
        .catch(error => {
          console.error('Error fetching payment details:', error);
          // Handle error (e.g., show error message)
        })
        .finally(() => {
          this.loading = false;
          setTimeout(() => {
            this.showContent = true;
          }, 300);
        });
    },
  },
};
</script>

<style scoped>
@keyframes fadeInDown {
  from {
    opacity: 0;
    transform: translate3d(0, -20px, 0);
  }
  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
}

.animate-fade-in-down {
  animation: fadeInDown 0.5s ease-out;
}
</style>
