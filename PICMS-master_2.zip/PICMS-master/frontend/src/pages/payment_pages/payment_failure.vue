<template>
  <div class="bg-background min-h-screen flex items-center justify-center">
    <div class="bg-cardLight p-8 rounded-lg shadow-md max-w-md mx-auto">
      <div class="flex items-center justify-center mb-6">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          class="h-16 w-16 text-red-500"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="2"
            d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      </div>
      <h1 class="text-2xl font-bold text-center mb-4">Payment Failed</h1>
      <p class="text-text text-center mb-6">
        We're sorry, but your payment could not be processed. Please try again or contact support if the issue persists.
      </p>
      <div class="mt-8 flex justify-center space-x-4">
        <RouterLink to="/dashboard"
          class="bg-secondary hover:bg-tertiary text-white font-bold py-2 px-4 rounded transition-colors duration-300"
        >
          Return to Dashboard
        </RouterLink>
        <RouterLink to="/contact-support"
          class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition-colors duration-300"
        >
          Contact Support
        </RouterLink>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  mounted() {
    // You can add any necessary logic here, such as logging the failure or notifying the user
    console.log('Payment failed');
  },
};
</script>
