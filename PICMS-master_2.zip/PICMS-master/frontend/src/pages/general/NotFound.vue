<template>
    <div class="wrapper">

        <h1>404 | Page Not Found</h1>

    </div>
</template>

<style scoped>
.wrapper {
    height: 100%;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>