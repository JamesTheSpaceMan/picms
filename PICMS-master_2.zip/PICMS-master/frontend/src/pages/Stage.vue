<template>
  <div>
    <h1>Stage</h1>
    <Multistep/>
  </div>
</template>

<script>
import Multistep from './multistep.vue';

export default {
  components: {
    Multistep
  }
}
</script>