<template>
    <div class="min-h-screen flex items-center justify-center bg-background px-4 sm:px-6 lg:px-8">
        <SetUPSystemForm />
    </div>
</template>

<script>
import SetUPSystemForm from './SetUPSystemForm.vue';

export default {
    components: {
        SetUPSystemForm
    }
}
</script>