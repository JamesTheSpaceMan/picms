<template>
  <div class="action-dispatcher">
    <!-- Dropdown orientation (default) -->
    <a-dropdown v-if="orientation === 'dropdown'" :trigger="['click']">
      <button class="action-dropdown" type="text">
        <i class="pi pi-ellipsis-h"></i>
      </button>
      <template #overlay>
        <a-menu class="custom-dropdown-menu">
          <ActionMenuItem 
            v-for="action in filteredActions" 
            :key="action.name" 
            :action="action" 
            :item="item"
            @action-click="handleAction"
          />
        </a-menu>
      </template>
    </a-dropdown>

    <!-- Buttons orientation -->
    <div v-else-if="orientation === 'buttons'" class="flex space-x-2">
      <button 
        v-for="action in filteredActions" 
        :key="action.name"
        :class="action.name === 'deleteResource' ? 'delete-button' : 'action-button'"
        @click="handleAction(item, action.name)"
      >
        <i :class="[action.icon, 'mr-2']"></i>
        {{ action.label }}
      </button>
    </div>

    <!-- Icons orientation -->
    <div v-else-if="orientation === 'icons'" class="flex space-x-10">
      <a-tooltip v-for="action in filteredActions" :key="action.name" :title="action.label">

          <i          shape="circle" 
          :class="action.name === 'deleteResource' ? `action-icon ${action.icon}` : `action-icon ${action.icon}`"
          @click="handleAction(item, action.name)"></i>
      
      </a-tooltip>
    </div>

    <!-- Modal orientation -->
    <div v-else-if="orientation === 'modal'">
      <button  @click="showModal = true" >
        <i class="pi pi-ellipsis-v"></i>
      </button>
      <a-modal v-model:visible="showModal" title="Select An Action" :cancellable="false" @ok="showModal = false">
        <a-list item-layout="horizontal" :data-source="filteredActions">
          <template #renderItem="{ item: action }">
            <a-list-item @click="handleAction(item, action.name)">
              <a-list-item-meta>
                <template #title>
                  <span :class="{ 'text-red-600': action.name === 'deleteResource' }">
                    <i :class="[action.icon, 'mr-2']"></i>
                    {{ action.label }}
                  </span>
                </template>
              </a-list-item-meta>
            </a-list-item>
          </template>
        </a-list>
      </a-modal>
    </div>

    <!-- List orientation -->
    <a-list v-else-if="orientation === 'list'" item-layout="horizontal" :data-source="filteredActions">
      <template #renderItem="{ item: action }">
        <a-list-item @click="handleAction(item, action.name)">
          <a-list-item-meta>
            <template #title>
              <span :class="{ 'text-red-600': action.name === 'deleteResource' }">
                <i :class="[action.icon, 'mr-2']"></i>
                {{ action.label }}
              </span>
            </template>
          </a-list-item-meta>
        </a-list-item>
      </template>
    </a-list>

    <!-- Grid orientation -->
    <div v-else-if="orientation === 'grid'" class="grid grid-cols-3 gap-2">
      <span 
        v-for="action in filteredActions" 
        :key="action.name"
        :color="action.name === 'deleteResource' ? 'danger' : 'primary'"
        @click="handleAction(item, action.name)"
        class="flex flex-col items-center justify-center p-2"
      >
        <i :class="[action.icon, 'text-xl mb-1']"></i>
        <span class="text-xs">{{ action.label }}</span>
      </span>
    </div>
  </div>
</template>

<script>
import { ref, computed } from 'vue';
import resourceFunctions from '../executables/actions';
import ActionMenuItem from './action_menu_item.vue';

export default {
  name: 'ActionDispatcher',
  components: {
    ActionMenuItem
  },
  props: {
    resource: {
      type: Object,
      required: true
    },
    item: {
      type: Object,
      required: true
    },
    orientation: {
      type: String,
      default: 'dropdown',
      validator: (value) => ['dropdown', 'buttons', 'icons', 'modal', 'list', 'grid'].includes(value)
    }
  },
  setup(props) {
    const loading = ref(false);
    const showModal = ref(false);

    const filteredActions = computed(() => 
      props.resource.actions.filter(a => a.name !== 'createResource')
    );

    const handleAction = async (item, actionName) => {
      loading.value = true;
      try {
        const actionConfig = resourceFunctions.find(action => action.key === actionName);
        if (actionConfig && typeof actionConfig.value === 'function') {
          await actionConfig.value({
            resource: props.resource.name,
            path: props.resource.path,
            id: item._id||item.id,
            data: item,
            mode: props.resource.renderMode,
            router: props.router
          });
          console.log(`Action ${actionName} performed successfully`);
        } else {
          console.warn(`Handler for action '${actionName}' is not a function or not found`);
        }
      } catch (error) {
        console.error(`Error performing action ${actionName}:`, error.message);
      } finally {
        loading.value = false;
        showModal.value = false;
      }
    };

    return {
      loading,
      showModal,
      filteredActions,
      handleAction
    };
  }
};
</script>

<style scoped>
.action-dispatcher {
  z-index: 2;
}

.action-dropdown {
  font-size: 1.2rem;
  color: black;
  background-color: transparent;
  border-radius: 100%;
  padding: 0px;
}

.action-dropdown i {
  color: var(--primary);
  color: var(--backgroundHover);
}

.action-dropdown:hover {
  color: var(--menubg);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0);
}
.custom-dropdown-menu {
  min-width: 160px;
}
</style>