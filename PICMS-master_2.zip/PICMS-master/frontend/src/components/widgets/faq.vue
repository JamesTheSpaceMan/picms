<template>
    <section class="py-12 bg-gray-100">
      <div class="container mx-auto px-4">
        <h2 class="text-3xl font-bold text-center mb-12">{{ props.title }}</h2>
        <div class="max-w-3xl mx-auto">
          <div v-for="(faq, index) in props.questions" :key="index" class="mb-6">
            <button @click="toggleFaq(index)" class="flex justify-between items-center w-full text-left font-semibold text-lg p-4 bg-white rounded-lg shadow-md hover:bg-gray-50">
              {{ faq.question }}
              <i :class="{'fa-chevron-down': !faq.isOpen, 'fa-chevron-up': faq.isOpen}" class="fas transition-transform duration-300"></i>
            </button>
            <div v-show="faq.isOpen" class="mt-2 p-4 bg-white rounded-lg">
              <p>{{ faq.answer }}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  
  const props = defineProps(['title', 'questions']);
  
  const faqs = ref(props.questions.map(q => ({ ...q, isOpen: false })));
  
  const toggleFaq = (index) => {
    faqs.value[index].isOpen = !faqs.value[index].isOpen;
  };
  </script>