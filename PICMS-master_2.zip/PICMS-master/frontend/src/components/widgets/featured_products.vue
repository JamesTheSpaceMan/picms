<template>
    <div class="max-w-screen-lg mx-auto mt-44">
      <h2 class="text-2xl font-bold mb-4 text-center">{{ type }}</h2>
      <Carousel
        :items-to-show="3"
        :wrap-around="true"
        class="relative overflow-hidden"
        v-if="filteredProducts.length"
      >
        <Slide v-for="product in filteredProducts" :key="product.id" class="p-4">
          <div class="bg-white shadow-md rounded-lg p-4 hover:shadow-xl transition-shadow duration-300">
            <img
              :src="product.images[0]"
              :alt="product.name"
              class="w-full h-48 object-cover rounded-t-lg"
            />
            <div class="p-4">
              <h3 class="text-lg font-semibold">{{ product.name }}</h3>
              <p class="text-gray-500 mt-1">{{ product.description }}</p>
              <div class="mt-4">
                <span class="text-xl font-bold text-green-600">${{ product.price }}</span>
                <span v-if="product.discount_percentage" class="ml-2 text-sm line-through text-gray-400">${{ discountedPrice(product) }}</span>
              </div>
            </div>
          </div>
        </Slide>
      </Carousel>
      <Pagination />
      <Navigation />
    </div>
  </template>
  
  <script>
  import { Carousel, Slide, Pagination, Navigation } from 'vue3-carousel';
  import products from '@/assets/data/product.json'; // Assuming your products data is in a JSON file
  
  export default {
    name: 'featuredProducts',
    props: {
      type: {
        type: String,
        required: true
      }
    },
    components: {
      Carousel,
      Slide,
      Pagination,
      Navigation
    },
    data() {
      return {
        products
      };
    },
    computed: {
      filteredProducts() {
        switch (this.type) {
          case 'Top-Rated Products':
            return this.products.filter(product => product.rating >= 4.5);
          case 'New Arrivals':
            return this.products.sort((a, b) => new Date(b.time_added) - new Date(a.time_added));
          case 'Trending Products':
            return this.products.sort((a, b) => b.views_count - a.views_count);
          case 'Highly Discounted Products':
            return this.products.filter(product => product.discount_percentage >= 10);
          case 'Most Viewed Products':
            return this.products.sort((a, b) => b.views_count - a.views_count);
          case 'Best Value for Money':
            return this.products.sort((a, b) => (b.rating / b.price) - (a.rating / a.price));
          default:
            return this.products;
        }
      }
    },
    methods: {
      discountedPrice(product) {
        return (product.price * (1 - product.discount_percentage / 100)).toFixed(2);
      }
    }
  };
  </script>
  
  <style scoped>
  .carousel__slide {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  </style>
  