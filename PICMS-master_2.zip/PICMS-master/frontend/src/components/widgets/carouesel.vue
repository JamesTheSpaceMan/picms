<template>
    <section class="py-12 bg-gray-100">
      <div class="container mx-auto px-4">
        <h2 class="text-3xl font-bold text-center mb-8">{{ props.title }}</h2>
        <div class="relative">
          <div class="overflow-hidden">
            <div class="flex transition-transform duration-300 ease-in-out" :style="{ transform: `translateX(-${currentIndex * 100}%)` }">
              <div v-for="item in props.items" :key="item.title" class="w-full flex-shrink-0">
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                  <img :src="item.imageUrl" :alt="item.title" class="w-full h-64 object-cover" />
                  <div class="p-6">
                    <h3 class="text-xl font-semibold mb-2">{{ item.title }}</h3>
                    <p class="text-gray-600 mb-4">{{ item.description }}</p>
                    <a :href="item.button.link" class="inline-block bg-secondary text-white px-4 py-2 rounded hover:bg-secondary transition duration-300">
                      {{ item.button.label }}
                    </a>
                  </div>
                </div>
            </div>
          </div>
        </div>
        <button @click="prevSlide" class="absolute top-1/2 left-4 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-md hover:bg-gray-100 transition duration-300">
          <i class="fas fa-chevron-left text-gray-600"></i>
        </button>
        <button @click="nextSlide" class="absolute top-1/2 right-4 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-md hover:bg-gray-100 transition duration-300">
          <i class="fas fa-chevron-right text-gray-600"></i>
        </button>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';

const props = defineProps(['title', 'items', 'autoplay', 'interval']);

const currentIndex = ref(0);
let autoplayInterval;

const nextSlide = () => {
  currentIndex.value = (currentIndex.value + 1) % props.items.length;
};

const prevSlide = () => {
  currentIndex.value = (currentIndex.value - 1 + props.items.length) % props.items.length;
};

onMounted(() => {
  if (props.autoplay) {
    autoplayInterval = setInterval(nextSlide, props.interval);
  }
});

onUnmounted(() => {
  if (autoplayInterval) {
    clearInterval(autoplayInterval);
  }
});
</script>