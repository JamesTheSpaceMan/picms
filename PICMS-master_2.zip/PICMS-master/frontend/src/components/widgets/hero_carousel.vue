<template>
    <section class="relative mt-16 md:mt-24 h-[80vh] md:h-[70vh] flex items-center justify-center overflow-hidden">
      <div class="absolute inset-0 z-0">
        <Carousel v-model="currentSlideIndex" :items="props.carouselItems" :wrap-around="true" :autoplay="5000">
          <Slide v-for="(item, index) in props.carouselItems" :key="index">
            <div class="w-full h-full">
              <img :src="item.imageUrl" :alt="item.imageAlt" class="w-full h-full object-right-bottom">
              <div class="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30"></div>
            </div>
          </Slide>
        </Carousel>
      </div>
      <div class="container mx-auto px-4 relative z-10 text-white">
        <div class="max-w-3xl mx-auto">
          <h1 class="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold mb-4 md:mb-6 leading-tight animate-fade-in-up">
            {{ currentSlide.title }}
          </h1>
          <h2 class="text-lg sm:text-xl md:text-2xl font-medium mb-4 md:mb-6 opacity-90 animate-fade-in-up animation-delay-300">
            {{ currentSlide.subtitle }}
          </h2>
          <p v-if="currentSlide.description" class="text-base md:text-lg mb-6 md:mb-10 opacity-80 animate-fade-in-up animation-delay-450">
            {{ currentSlide.description }}
          </p>
          <a :href="currentSlide.button.link" class="bg-white text-secondary hover:bg-secondary hover:text-white font-bold py-3 px-6 md:py-4 md:px-8 rounded-full transition duration-300 inline-flex items-center group animate-fade-in-up animation-delay-600">
            <i :class="currentSlide.button.icon" class="mr-2 group-hover:translate-x-1 transition-transform"></i>
            {{ currentSlide.button.label }}
          </a>
        </div>
      </div>
      <div class="absolute bottom-0 left-0 right-0 h-24 md:h-32 bg-gradient-to-t from-black/70 to-transparent"></div>
    </section>
  </template>
  
  <script setup>
  import { ref, computed } from 'vue';
  import { Carousel, Slide } from 'vue3-carousel';

  
  const props = defineProps({
    carouselItems: {
      type: Array,
      required: true,
    },
    layout: {
      type: String,
      default: 'center',
    },
  });
  
  const currentSlideIndex = ref(0);
  
  const currentSlide = computed(() => props.carouselItems[currentSlideIndex.value]);
  
  const layoutClass = computed(() => {
    switch (props.layout) {
      case 'left':
        return 'text-left';
      case 'right':
        return 'text-right';
      default:
        return 'text-center';
    }
  });
  </script>
  
  <style scoped>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  .animate-fade-in-up {
    animation: fadeInUp 0.6s ease-out forwards;
  }
  
  .animation-delay-300 {
    animation-delay: 0.3s;
  }
  
  .animation-delay-450 {
    animation-delay: 0.45s;
  }
  
  .animation-delay-600 {
    animation-delay: 0.6s;
  }
  
  /* Mobile-specific styles */
  @media (max-width: 640px) {
    .container {
      padding-left: 1rem;
      padding-right: 1rem;
    }
  
    h1, h2, p {
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
    }
  }
  </style>