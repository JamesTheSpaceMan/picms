<template>
  <div class="sales-report">    
    <div id="charts-container">
      <div class="chart-container">
        <apexchart
          ref="barChart"
          type="bar"
          height="350"
          :options="barChartOptions"
          :series="barChartSeries"
        ></apexchart>
      </div>

      
      <div class="chart-container">
        <apexchart
          ref="pieChart"
          type="pie"
          height="350"
          :options="pieChartOptions"
          :series="pieChartSeries"
        ></apexchart>
      </div>
    </div>
    
    <div class="summary">
      <h2>Summary</h2>
      <p>Total Sales: {{ formatCurrency(totalSales) }}</p>
      <p>Average Order Value: {{ formatCurrency(averageOrderValue) }}</p>
      <p>Total sales: {{ totalOrders }}</p>
    </div>
    
    <button @click="generatePDF" class="generate-pdf-btn">Generate PDF Report</button>
  </div>
</template>

<script>
import { defineComponent, ref, computed, nextTick } from 'vue';
import VueApexCharts from 'vue3-apexcharts';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import html2canvas from 'html2canvas';

export default defineComponent({
  name: 'SalesReport',
  components: {
    apexchart: VueApexCharts,
  },
  setup() {
    const salesData = ref([
      { date: '2024-10-01', amount: 15000, orders: 5 },
      { date: '2024-10-02', amount: 22000, orders: 7 },
      { date: '2024-10-03', amount: 18000, orders: 6 },
      { date: '2024-10-04', amount: 30000, orders: 10 },
      { date: '2024-10-05', amount: 25000, orders: 8 },
    ]);

    const totalSales = computed(() => 
      salesData.value.reduce((sum, day) => sum + day.amount, 0)
    );

    const totalOrders = computed(() => 
      salesData.value.reduce((sum, day) => sum + day.orders, 0)
    );

    const averageOrderValue = computed(() => 
      totalSales.value / totalOrders.value
    );

    const barChartOptions = {
      chart: {
        id: 'sales-chart',
      },
      xaxis: {
        categories: salesData.value.map(day => day.date),
      },
      yaxis: [
        {
          title: {
            text: 'Sales Amount',
          },
        },
        {
          opposite: true,
          title: {
            text: 'Number of sales',
          },
        },
      ],
    };

    const barChartSeries = [
      {
        name: 'Sales Amount',
        data: salesData.value.map(day => day.amount),
      },
      {
        name: 'Number of Orders',
        data: salesData.value.map(day => day.orders),
      },
    ];

    const lineChartOptions = {
      chart: {
        id: 'sales-trend-chart',
      },
      xaxis: {
        categories: salesData.value.map(day => day.date),
      },
      yaxis: {
        title: {
          text: 'Sales Amount',
        },
      },
    };

    const lineChartSeries = [
      {
        name: 'Sales Trend',
        data: salesData.value.map(day => day.amount),
      },
    ];

    const pieChartOptions = {
      chart: {
        id: 'sales-distribution-chart',
      },
      labels: salesData.value.map(day => day.date),
    };

    const pieChartSeries = salesData.value.map(day => day.amount);

    const formatCurrency = (amount) => {
      return new Intl.NumberFormat('en-mw', { style: 'currency', currency: 'MWK' }).format(amount);
    };

    const generatePDF = async () => {
      const doc = new jsPDF();

      // Add title
      doc.setFontSize(20);
      doc.text('Sales Report', 105, 15, { align: 'center' });

      // Add summary
      doc.setFontSize(12);
      doc.text(`Total Sales: ${formatCurrency(totalSales.value)}`, 20, 30);
      doc.text(`Average Order Value: ${formatCurrency(averageOrderValue.value)}`, 20, 40);
      doc.text(`Total Orders: ${totalOrders.value}`, 20, 50);

      // Function to add a chart to the PDF
      const addChartToPDF = async (chartRef, title, yPosition) => {
        if (chartRef.value && chartRef.value.$el) {
          const canvas = await html2canvas(chartRef.value.$el);
          const imgData = canvas.toDataURL('image/png');
          doc.addImage(imgData, 'PNG', 10, yPosition, 190, 100);
          doc.text(title, 105, yPosition - 5, { align: 'center' });
        }
      };

      // Ensure charts are rendered before capturing
      await nextTick();

      // Add bar chart
      await addChartToPDF(barChart, 'Sales and Orders Bar Chart', 70);

      // Add line chart
      await addChartToPDF(lineChart, 'Sales Trend Line Chart', 180);

      // Add pie chart
      await addChartToPDF(pieChart, 'Sales Distribution Pie Chart', 290);

      // Add sales data table on a new page
      doc.addPage();
      doc.autoTable({
        startY: 20,
        head: [['Date', 'Sales Amount', 'Number of Orders']],
        body: salesData.value.map(day => [
          day.date,
          formatCurrency(day.amount),
          day.orders,
        ]),
      });

      // Save the PDF
      doc.save('sales-report.pdf');
    };

    const barChart = ref(null);
    const lineChart = ref(null);
    const pieChart = ref(null);

    return {
      barChart,
      lineChart,
      pieChart,
      barChartOptions,
      barChartSeries,
      lineChartOptions,
      lineChartSeries,
      pieChartOptions,
      pieChartSeries,
      totalSales,
      averageOrderValue,
      totalOrders,
      formatCurrency,
      generatePDF,
    };
  },
});
</script>

<style scoped>
.sales-report {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.chart-container {
  margin-bottom: 30px;
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  padding: 15px;
}

.summary {
  background-color: #f0f2f5;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
}

.generate-pdf-btn {
  background-color: #1890ff;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s;
}

.generate-pdf-btn:hover {
  background-color: #40a9ff;
}
</style>