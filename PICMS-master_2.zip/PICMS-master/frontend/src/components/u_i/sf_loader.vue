<template>
  <div class="loader" ref="loader"></div>
</template>

<script>
export default {
  mounted() {
    this.startLoading();
  },
  beforeUnmount() {
    this.stopLoading();
  },
  methods: {
    startLoading() {
      this.originalTitle = document.title;
      this.loadingInterval = setInterval(() => {
        document.title = document.title.startsWith('Loading') ? this.originalTitle : 'Loading...';
      }, 1000);
    },
    stopLoading() {
      clearInterval(this.loadingInterval);
      document.title = this.originalTitle;
    }
  }
}
</script>

<style scoped>
.loader {
  font-weight: bold;
  font-family: sans-serif;
  font-size: 30px;
  animation: l1 1s linear infinite alternate;
}
.loader:before {
  content: "Loading...";
}
@keyframes l1 {to{opacity: 0}}
</style>