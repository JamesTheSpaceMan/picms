<template>
  <div class="flex justify-center w-screen my-14 font-bold px-4">

      <slot></slot>

  </div>
</template>
