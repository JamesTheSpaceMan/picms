<script setup>
import { ref, computed, onMounted, watch, onUnmounted } from 'vue';
import { systemConfig } from '../../../data/system.config';
import { useRoute, useRouter } from 'vue-router';
import Logo from '../../u_i/sf_logo.vue';
import { getFilteredResources } from '../../../executables/accessControl';
import { getUserWithRole } from '../../../executables/getSanitizedUser';
import { translationKeys } from '@/executables/translation';
import Swal from 'sweetalert2';
import breadcrumbs from '../../breadcrumbs.vue';
import themeCustomizer from '../../theme-customizer.vue';
import notifications_dropdown from '../render_modes/notifications/notifications_dropdown.vue';

const drawerOpen = ref(true);
const isMinimized = ref(false);
const profileDrawerOpen = ref(false);
const openMenuGroups = ref([]);
const userName = ref(null);
const avatarUrl = ref(null);
const userEmail = ref(null);
const userRole = ref(null);
const Resources = ref(null);
const user = ref(null);

const route = useRoute();
const router = useRouter();

const portalName = computed(() => {
  const segments = route.path.split('/');
  return segments.length > 1 ? segments[1] : '';
});

const menuItems = computed(() => {
  if (!Resources.value) return [];

  const sortedResources = [...Resources.value].sort((a, b) => a.order - b.order);

  // First, group by resourceGroup
  const groupedByResourceGroup = {};
  sortedResources.forEach(resource => {
    const group = resource.resourceGroup || 'Ungrouped';
    if (!groupedByResourceGroup[group]) {
      groupedByResourceGroup[group] = [];
    }
    groupedByResourceGroup[group].push(resource);
  });

  // Then, process each resourceGroup
  return Object.entries(groupedByResourceGroup).map(([groupName, resources]) => {
    const processedItems = [];
    const menuGroups = {};

    resources.forEach(resource => {
      if (resource.menuGroup) {
        if (!menuGroups[resource.menuGroup]) {
          menuGroups[resource.menuGroup] = {
            type: 'menuGroup',
            name: resource.menuGroup,
            label: resource.menuGroup,
            icon: resource.menuGroupIcon,
            resources: []
          };
          processedItems.push(menuGroups[resource.menuGroup]);
        }
        menuGroups[resource.menuGroup].resources.push(resource);
      } else {
        processedItems.push({
          type: 'resource',
          ...resource
        });
      }
    });

    return {
      resourceGroup: groupName,
      items: processedItems
    };
  });
});

const toggleDrawer = () => {
  if (drawerOpen.value) {
    if (isMinimized.value) {
      isMinimized.value = false;
      drawerOpen.value = false;
    } else {
      isMinimized.value = true;
    }
  } else {
    drawerOpen.value = true;
    isMinimized.value = false;
  }
};

const isActive = (path) => {
  return route.name === `${portalName.value}-${path}`;
};

const toggleMenuGroup = (name) => {
  if (isMinimized.value) {
    isMinimized.value = false;
    drawerOpen.value = true;
  }
  
  const index = openMenuGroups.value.indexOf(name);
  if (index === -1) {
    openMenuGroups.value.push(name);
  } else {
    openMenuGroups.value.splice(index, 1);
  }
};

const isMenuGroupOpen = (name) => openMenuGroups.value.includes(name);

const openProfileDrawer = () => {
  profileDrawerOpen.value = true;
};

const closeProfileDrawer = () => {
  profileDrawerOpen.value = false;
};

const logout = async () => {
  const result = await Swal.fire({
    title: translationKeys.AreYouSure,
    text: translationKeys.DoYouWantToLogout,
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: translationKeys.YesLogout,
  });
  if (result.isConfirmed) {
    localStorage.removeItem("authToken");
    localStorage.removeItem("userName");
    localStorage.removeItem("userId");
    localStorage.removeItem("systemname");
    localStorage.removeItem("systemlogo");
    localStorage.removeItem("user");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("role");
    localStorage.removeItem("userImage");
    router.push("/login");
    await Swal.fire({
      icon: "success",
      title: translationKeys.Success,
      text: translationKeys.LoggedOut,
    });
  } else {
    await Swal.fire({
      title: translationKeys.Cancelled,
      text: translationKeys.StillLoggedIn,
      icon: "info",
    });
  }
};

// Handle keyboard shortcuts for sidebar
const handleKeyPress = (event) => {
  // Ctrl/Cmd + B to toggle sidebar
  if ((event.ctrlKey || event.metaKey) && event.key === 'b') {
    event.preventDefault();
    toggleDrawer();
  }
};

// Handle screen resize
const handleResize = () => {
  if (window.innerWidth < 768) {
    drawerOpen.value = false;
    isMinimized.value = false;
  }
};

onMounted(async () => {
  const roleId = localStorage.getItem("role");
  if (roleId) {
    try {
      const allResources = await getFilteredResources(roleId);
      const currentPortal = systemConfig.portals.find(portal => portal.url === `/${portalName.value}`);
      Resources.value = allResources.filter(resource =>
        currentPortal.resources.some(portalResource => portalResource.path === resource.path)
      );
    } catch (error) {
      console.error('Error fetching resources:', error);
    }
  }

  userName.value = localStorage.getItem("userName");
  avatarUrl.value = localStorage.getItem("userImage");
  userEmail.value = localStorage.getItem("userEmail");
  userRole.value = localStorage.getItem("role");

  const userId = localStorage.getItem('userId');
  if (userId) {
    try {
      user.value = await getUserWithRole(userId);
    } catch (error) {
      console.error('Error:', error);
    }
  }

  if (!localStorage.getItem("userName")) {
    router.push("/");
  }

  // Add event listeners
  window.addEventListener('keydown', handleKeyPress);
  window.addEventListener('resize', handleResize);
  
  // Initial check for screen size
  handleResize();
});

onUnmounted(() => {
  // Clean up event listeners
  window.removeEventListener('keydown', handleKeyPress);
  window.removeEventListener('resize', handleResize);
});

// Watch for route changes to handle mobile view
watch(route, () => {
  if (window.innerWidth < 768) {
    drawerOpen.value = false;
    isMinimized.value = false;
  }
});
</script>

<template>
  <div class="flex flex-col h-screen overflow-hidden bg-background">
    <!-- Top Bar -->
    <div class="h-16 bg-primary shadow-sm flex items-center justify-between px-4 z-50">
      <div class="flex items-center space-x-4">
        <button @click="toggleDrawer" class="p-2 rounded-lg hover:bg-gray-100 transition-colors">
          <i class="fas fa-bars text-gray-600"></i>
        </button>
        <div class="">
          <Logo />
        </div>
      </div>
      
      <div class="flex items-center space-x-4">
        <themeCustomizer class="text-gray-600"/>
        <notifications_dropdown class="text-gray-600"/>
        <button @click="openProfileDrawer" 
                class="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-100 transition-colors">
          <img :src="avatarUrl" 
               alt="Profile" 
               class="h-8 w-8 rounded-full object-cover border-2 border-gray-200"/>
          <span class="text-sm font-medium text-gray-700">{{ userName }}</span>
        </button>
      </div>
    </div>

    <!-- Main content area -->
    <div class="flex flex-1 overflow-hidden">
      <!-- Sidebar -->
      <div :class="[
        'transition-all duration-300 ease-in-out bg-cardLight border-r',
        {
          'w-64': drawerOpen && !isMinimized,
          'w-16': isMinimized,
          'w-0': !drawerOpen
        }
      ]">
        <nav class="h-full overflow-y-auto">
          <div class="p-4" :class="{ 'px-2': isMinimized }">
            <!-- Dashboard Link -->
            <RouterLink to="/dashboard" 
                      class="flex items-center p-2 rounded-lg hover:bg-gray-100 transition-colors mb-4">
              <i class="pi pi-home text-gray-600"></i>
              <span v-if="!isMinimized" class="ml-3 text-sm font-medium text-gray-700">
                {{ translationKeys.Home }}
              </span>
            </RouterLink>

            <!-- Menu Items -->
            <template v-for="group in menuItems" :key="group.resourceGroup">
              <div v-if="!isMinimized" class="text-xs font-semibold text-background0 uppercase tracking-wider mt-6 mb-2">
                {{ group.resourceGroup }}
              </div>
              
              <template v-for="item in group.items" :key="item.name || item.path">
                <!-- Single items -->
                <RouterLink v-if="item.type === 'resource'"
                          :to="`/${portalName}/${item.path}`"
                          class="flex items-center p-2 rounded-lg hover:bg-gray-100 transition-colors mb-1">
                  <i :class="[item.icon, 'text-gray-600']"></i>
                  <span v-if="!isMinimized" class="ml-3 text-sm font-medium text-gray-700">
                    {{ item.label }}
                  </span>
                </RouterLink>

                <!-- Group items -->
                <div v-else-if="item.type === 'menuGroup'">
                  <button @click="toggleMenuGroup(item.name)"
                          class="w-full flex items-center p-2 rounded-lg hover:bg-gray-100 transition-colors">
                    <i :class="[item.icon, 'text-gray-600']"></i>
                    <template v-if="!isMinimized">
                      <span class="ml-3 text-sm font-medium text-gray-700">{{ item.label }}</span>
                      <i :class="[
                        'fas ml-auto transition-transform duration-200',
                        isMenuGroupOpen(item.name) ? 'fa-chevron-down' : 'fa-chevron-right'
                      ]"></i>
                    </template>
                  </button>
                  
                  <div v-if="!isMinimized && isMenuGroupOpen(item.name)"
                       class="ml-4 space-y-1">
                    <RouterLink v-for="resource in item.resources"
                              :key="resource.name"
                              :to="`/${portalName}/${resource.path}`"
                              class="flex items-center p-2 rounded-lg hover:bg-gray-100 transition-colors">
                      <i :class="[resource.icon, 'text-gray-600']"></i>
                      <span class="ml-3 text-sm font-medium text-gray-700">
                        {{ resource.label }}
                      </span>
                    </RouterLink>
                  </div>
                </div>
              </template>
            </template>
          </div>
        </nav>
      </div>

      <!-- Main Content -->
      <div class="flex-1 overflow-y-auto bg-background">
        <div class="p-6">
          <breadcrumbs />
          <slot />
        </div>
      </div>

      <!-- Profile Drawer -->
      <div v-if="profileDrawerOpen"
           class="fixed z-50 inset-y-0 right-0 w-80 bg-white shadow-lg transform transition-transform duration-300">
        <div class="p-6">
          <div class="flex justify-between items-center mb-6">
            <h2 class="text-xl font-semibold text-gray-800">{{ translationKeys.Profile }}</h2>
            <button @click="closeProfileDrawer" 
                    class="p-2 rounded-lg hover:bg-gray-100 transition-colors">
              <i class="fas fa-times text-gray-600"></i>
            </button>
          </div>
          
          <div class="text-center mb-6">
            <img :src="avatarUrl" 
                 alt="Profile" 
                 class="w-32 h-32 rounded-full mx-auto mb-4 object-cover border-4 border-gray-200"/>
            <h3 class="text-lg font-semibold text-gray-800">{{ user?.fullname }}</h3>
          </div>
          
          <div class="space-y-2 mb-6">
            <p class="text-sm text-gray-600">{{ translationKeys.Email }}: {{ user?.email }}</p>
            <p class="text-sm text-gray-600">{{ translationKeys.Role }}: {{ user?.role }}</p>
          </div>
          
          <div class="space-y-3">
            <RouterLink :to="`/${portalName}/profile`"
                       class="block w-full px-4 py-2 text-sm font-medium text-center text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
              <i class="fas fa-user mr-2"></i>{{ translationKeys.Profile }}
            </RouterLink>
            <button @click="logout"
                    class="w-full px-4 py-2 text-sm font-medium text-center text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors">
              <i class="fas fa-sign-out-alt mr-2"></i>{{ translationKeys.Logout }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>