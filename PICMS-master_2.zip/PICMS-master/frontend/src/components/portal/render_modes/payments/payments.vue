<template>
    <div class="payments-container">
      <a-empty v-if="payments.length === 0" description="No payments found" />
      <div v-else class="payments-list">
        <div v-for="payment in filteredPayments" :key="payment.id" class="payment-card">
          <div class="payment-header">
            <span class="amount">{{ formatCurrency(payment.amount, payment.currency) }}</span>
            <a-tag :color="getStatusColor(payment.paymentStatus)">{{ payment.paymentStatus }}</a-tag>
          </div>
          <div class="payment-details">
            <p><i class="pi pi-calendar"></i> {{ formatDate(payment.purchaseTime) }}</p>
            <p><i class="pi pi-credit-card"></i> {{ payment.paymentMethod }}</p>
          </div>
          <a-button type="primary" @click="generateReceipt(payment)">
            <i class="pi pi-file-pdf"></i> Generate Receipt
          </a-button>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import { defineComponent, ref, computed, onMounted } from 'vue';
  import { Empty, Tag, Button } from 'ant-design-vue';
  import jsPDF from 'jspdf';
  import 'jspdf-autotable';
  import QRCode from 'qrcode';
  
  export default defineComponent({
    components: {
      AEmpty: Empty,
      ATag: Tag,
      AButton: Button,
    },
    props: {
      fetchMode: {
        type: String,
        default: 'all',
        validator: (value) => ['all', 'user'].includes(value),
      },
    },
    setup(props) {
      const payments = ref([]);
  
      const fetchPayments = async () => {
        try {
          const response = await fetch(`${import.meta.env.VITE_APP_API_URL}/api/v1/payments`);
          const data = await response.json();
          payments.value = data.data;
        } catch (error) {
          console.error('Error fetching payments:', error);
        }
      };
  
      const filteredPayments = computed(() => {
        if (props.fetchMode === 'user') {
          const userId = localStorage.getItem('userId');
          return payments.value.filter(payment => payment.metadata.customerId === userId);
        }
        return payments.value;
      });
  
      const formatCurrency = (amount, currency) => {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: currency.toUpperCase() }).format(amount);
      };
  
      const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric', 
          hour: '2-digit', 
          minute: '2-digit' 
        });
      };
  
      const getStatusColor = (status) => {
        const colors = {
          paid: 'success',
          pending: 'warning',
          failed: 'error',
        };
        return colors[status] || 'default';
      };
  
      const generateReceipt = async (payment) => {
        const doc = new jsPDF();
        
        // Add makeshift logo
        doc.setFontSize(10);
        doc.setFont('courier', 'normal');
        const logo = [
          "  ____       _                 ",
          " |  _ \\ _ __(_)_ __ ___   ___  ",
          " | |_) | '__| | '_ ` _ \\ / _ \\ ",
          " |  __/| |  | | | | | | |  __/ ",
          " |_|   |_|  |_|_| |_| |_|\\___| ",
          "    Insurance Ltd.             "
        ];
        logo.forEach((line, index) => {
          doc.text(line, 15, 10 + (index * 5));
        });
        
        // Add receipt title and number
        doc.setFontSize(20);
        doc.setFont('helvetica', 'bold');
        doc.text('Payment Receipt', 105, 50, { align: 'center' });
        doc.setFontSize(12);
        doc.text(`Receipt Number: ${payment.paymentIntentId}`, 105, 60, { align: 'center' });
        
        // Add QR code
        const qrCodeData = await QRCode.toDataURL(payment.paymentIntentId);
        doc.addImage(qrCodeData, 'PNG', 170, 10, 30, 30);
  
        // Add payment details
        doc.autoTable({
          startY: 70,
          head: [['Item', 'Details']],
          body: [
            ['Receipt Number', payment.paymentIntentId],
            ['Amount', formatCurrency(payment.amount, payment.currency)],
            ['Status', payment.paymentStatus],
            ['Method', payment.paymentMethod],
            ['Date', formatDate(payment.purchaseTime)],
            ['Customer', payment.metadata.customerName],
            ['Email', payment.metadata.customerEmail],
          ],
        });
  
        // Add items table
        doc.autoTable({
          startY: doc.lastAutoTable.finalY + 10,
          head: [['Item', 'Quantity', 'Amount']],
          body: payment.items.map(item => [
            item.name,
            item.quantity,
            formatCurrency(item.amount, payment.currency),
          ]),
        });
  
        // Save the PDF
        doc.save(`receipt-${payment.paymentIntentId}.pdf`);
      };
  
      onMounted(fetchPayments);
  
      return {
        payments,
        filteredPayments,
        formatCurrency,
        formatDate,
        getStatusColor,
        generateReceipt,
      };
    },
  });
  </script>
  
  <style scoped>
  .payments-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
  }
  
  .title {
    font-size: 24px;
    margin-bottom: 20px;
    color: #1890ff;
  }
  
  .payments-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
  }
  
  .payment-card {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    padding: 16px;
    transition: all 0.3s;
  }
  
  .payment-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  }
  
  .payment-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }
  
  .amount {
    font-size: 18px;
    font-weight: bold;
    color: #52c41a;
  }
  
  .payment-details {
    margin-bottom: 12px;
  }
  
  .payment-details p {
    margin: 6px 0;
    display: flex;
    align-items: center;
  }
  
  .payment-details i {
    margin-right: 8px;
    color: #1890ff;
  }
  
  .ant-btn {
    width: 100%;
  }
  </style>