<template>
  <div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6 flex items-center">
      <i class="pi pi-shield mr-2 text-blue-500"></i>Available Policies
    </h1>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <div v-for="policy in policies" :key="policy.id" class="bg-white rounded-lg shadow-lg overflow-hidden transition-transform duration-300 hover:scale-105">
        <img :src="policy.image" :alt="policy.policyName" class="w-full h-48 object-cover">
        <div class="p-6">
          <h2 class="text-xl font-semibold mb-2 flex items-center">
            <i :class="policy.icon" class="mr-2 text-blue-500"></i>
            {{ policy.policyName }}
          </h2>
          <p class="text-gray-600 mb-2 flex items-center">
            <i class="pi pi-id-card mr-2"></i>
            Policy Number: {{ policy.policyNumber }}
          </p>

          <button
            @click="openPolicyForm(policy)"
            class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded w-full flex items-center justify-center"
          >
            <i class="pi pi-check-circle mr-2"></i>
            Subscribe
          </button>
        </div>
      </div>
    </div>

    <!-- Policy Form Modal -->
    <div v-if="showModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
      <div class="bg-white p-8 w-full h-full overflow-y-auto">
        <div class="flex justify-between items-center mb-4">
          <button @click="closeModal" class="text-blue-500 hover:text-blue-600">
            <i class="pi pi-arrow-left mr-2"></i>Back
          </button>
          <h2 class="text-2xl font-bold">{{ selectedPolicy.policyName }} Subscription</h2>
          <div class="flex space-x-2">
            <button @click="saveAsDraft" class="bg-gray-500 hover:bg-gray-600 text-white px-3 py-1 rounded flex items-center">
              <i class="pi pi-save mr-2"></i>Save Draft
            </button>
            <button @click="generatePDF" class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded flex items-center">
              <i class="pi pi-file-pdf mr-2"></i>Download PDF
            </button>
          </div>
        </div>
        <div class="flex">
          <div class="w-2/3 pr-4">
            <form @submit.prevent="submitForm" class="space-y-4">
              <!-- Liability Cover Form -->
              <div v-if="selectedPolicy.policyName === 'Liability cover'" class="grid grid-cols-2 gap-4">
                <vue-multiselect v-model="formData.businessType" :options="businessTypes" placeholder="Business Type" class="vue-multiselect"/>
                <input v-model.number="formData.annualRevenue" type="number" placeholder="Annual Revenue (MWK)" class="p-2 border rounded">
                <input v-model.number="formData.employeeCount" type="number" placeholder="Number of Employees" class="p-2 border rounded">
                <vue-multiselect v-model="formData.claimsHistory" :options="['Yes', 'No']" placeholder="Previous Claims History" class="vue-multiselect"/>
              </div>

              <!-- Life Cover Form -->
              <div v-if="selectedPolicy.policyName === 'Life Cover'" class="grid grid-cols-2 gap-4">
                <input v-model="formData.fullName" placeholder="Full Name" class="p-2 border rounded">
                <input v-model="formData.dateOfBirth" type="date" placeholder="Date of Birth" class="p-2 border rounded">
                <vue-multiselect v-model="formData.occupation" :options="occupations" placeholder="Occupation" class="vue-multiselect"/>
                <vue-multiselect v-model="formData.smoker" :options="['Yes', 'No']" placeholder="Smoker" class="vue-multiselect"/>
                <input v-model.number="formData.coverageAmount" type="number" placeholder="Desired Coverage Amount (MWK)" class="p-2 border rounded">
              </div>

              <!-- Health Policy Form -->
              <div v-if="selectedPolicy.policyName === 'Health Policy'" class="grid grid-cols-2 gap-4">
                <input v-model="formData.fullName" placeholder="Full Name" class="p-2 border rounded">
                <input v-model="formData.dateOfBirth" type="date" placeholder="Date of Birth" class="p-2 border rounded">
                <vue-multiselect v-model="formData.gender" :options="['Male', 'Female', 'Other']" placeholder="Select Gender" class="vue-multiselect"/>
                <input v-model.number="formData.weight" type="number" placeholder="Weight (kg)" class="p-2 border rounded">
                <input v-model.number="formData.height" type="number" placeholder="Height (cm)" class="p-2 border rounded">
                <vue-multiselect v-model="formData.smoker" :options="['Yes', 'No']" placeholder="Smoker" class="vue-multiselect"/>
                <textarea v-model="formData.familyHistory" placeholder="Family Health History" class="p-2 border rounded col-span-2"></textarea>
                <vue-multiselect v-model="formData.currentConditions" :options="healthConditions" :multiple="true" :close-on-select="false" placeholder="Current Health Conditions" class="vue-multiselect col-span-2"/>
              </div>

              <!-- Car Policy Form -->
              <div v-if="selectedPolicy.policyName === 'Car Policy'" class="grid grid-cols-2 gap-4">
                <vue-multiselect v-model="formData.carMake" :options="carMakes" placeholder="Car Make" class="vue-multiselect"/>
                <input v-model="formData.carModel" placeholder="Car Model" class="p-2 border rounded">
                <input v-model.number="formData.carYear" type="number" placeholder="Car Year" class="p-2 border rounded">
                <input v-model="formData.licensePlate" placeholder="License Plate Number" class="p-2 border rounded">
                <input v-model="formData.driverLicense" placeholder="Driver's License Number" class="p-2 border rounded">
                <input v-model.number="formData.annualMileage" type="number" placeholder="Annual Mileage" class="p-2 border rounded">
                <vue-multiselect v-model="formData.parkingLocation" :options="['Garage', 'Driveway', 'Street']" placeholder="Parking Location" class="vue-multiselect"/>
                <vue-multiselect v-model="formData.previousClaims" :options="['Yes', 'No']" placeholder="Previous Claims" class="vue-multiselect"/>
              </div>

              <!-- Fallback message if no form is shown -->
              <div v-if="!selectedPolicy.policyName">
                <p>No form available for this policy type.</p>
              </div>

              <div class="flex justify-between mt-6">
                <button type="submit" @click="submitForm('stripe')" class="bg-blue-800 hover:bg-blue-600 text-white px-4 py-2 rounded flex items-center justify-center" :disabled="isLoading">
                  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQGluJhW7I1NYU7jF77E-9K9I46_ib_DUNHw&s" alt="Stripe" class="w-6 h-6 mr-2">
                  <span v-if="!isLoading">Pay with Stripe</span>
                  <span v-else class="flex items-center">
                    <i class="pi pi-spinner animate-spin mr-2"></i>
                    Processing...
                  </span>
                </button>
                <button type="button" @click="submitForm('paypal')" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded flex items-center justify-center" :disabled="isLoading">
                  <i class="pi pi-paypal mr-2"></i>
                  <span v-if="!isLoading">Pay with PayPal</span>
                  <span v-else class="flex items-center">
                    <i class="pi pi-spinner animate-spin mr-2"></i>
                    Processing...
                  </span>
                </button>
              </div>
            </form>
          </div>
          <div class="w-1/3 pl-4 border-l">
            <h3 class="text-xl font-semibold mb-4">Policy Price Preview</h3>
            <div class="bg-gray-100 p-4 rounded-lg">
              <p class="text-lg font-medium">Calculated Premium:</p>
              <p class="text-2xl font-bold text-blue-600">{{ formatCurrency(calculatePremium()) }}</p>
              <div class="mt-4">
                <p class="font-medium">Total Premium: {{ formatCurrency(calculatePremium()) }} MWK</p>
                <p v-if="selectedPaymentMethod === 'paypal'" class="text-sm text-gray-600">
                  Approximately {{ formatUSD(convertMWKtoUSD(calculatePremium())) }} USD for PayPal
                </p>
              </div>
              <ul class="mt-4 space-y-2">
                <li v-for="(value, key) in formData" :key="key" class="flex justify-between">
                  <span class="font-medium">{{ key }}:</span>
                  <span>{{ Array.isArray(value) ? value.join(', ') : value }}</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import { loadStripe } from '@stripe/stripe-js';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import VueMultiselect from 'vue-multiselect';

export default {
  components: {
    VueMultiselect
  },
  data() {
    return {
      policies: [
        {
          id: "66f14a6338811ad78da071ac",
          policyNumber: "POL-b1f4fe30",
          policyName: "Liability cover",
          premium: 12000,
          status: "active",
          icon: "pi pi-briefcase",
          image: "https://images.pexels.com/photos/7821464/pexels-photo-7821464.jpeg?auto=compress&cs=tinysrgb&w=800"
        },
        {
          id: "66f13eec38811ad78da06ff9",
          policyNumber: "POL-ffa09436",
          policyName: "Life Cover",
          premium: 12000,
          status: "active",
          icon: "pi pi-heart",
          image: "https://images.pexels.com/photos/7821467/pexels-photo-7821467.jpeg?auto=compress&cs=tinysrgb&w=800"
        },
        {
          id: "66f13bbd38811ad78da06f49",
          policyNumber: "POL-eee2d363",
          policyName: "Health Policy",
          premium: 60000,
          status: "active",
          icon: "pi pi-heart-fill",
          image: "https://images.pexels.com/photos/7163956/pexels-photo-7163956.jpeg?auto=compress&cs=tinysrgb&w=800"
        },
        {
          id: "66f13b9b38811ad78da06f24",
          policyNumber: "POL-72be1709",
          policyName: "Car Policy",
          premium: 12000,
          status: "active",
          icon: "pi pi-car",
          image: "https://images.pexels.com/photos/1134857/pexels-photo-1134857.jpeg?auto=compress&cs=tinysrgb&w=800"
        },
      ],
      showModal: false,
      selectedPolicy: null,
      formData: {},
      userId: localStorage.getItem('userId') || 'defaultUser',
      businessTypes: ['Retail', 'Manufacturing', 'Service', 'Technology', 'Other'],
      occupations: ['Engineer', 'Doctor', 'Teacher', 'Lawyer', 'Other'],
      healthConditions: ['Diabetes', 'Hypertension', 'Asthma', 'Heart Disease', 'Cancer'],
      carMakes: ['Toyota', 'Honda', 'Ford', 'Chevrolet', 'Nissan', 'Other'],
      isLoading: false,
      selectedPaymentMethod: 'stripe',
    };
  },
  methods: {
    formatCurrency(amount) {
      return new Intl.NumberFormat('en-MW', {
        style: 'currency',
        currency: 'MWK',
        minimumFractionDigits: 2,
      }).format(amount);
    },

    formatUSD(amount) {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
      }).format(amount);
    },

    openPolicyForm(policy) {
      this.selectedPolicy = policy;
      this.initializeFormData(policy.policyName);
      this.showModal = true;
      this.loadDraftData();
      console.log('Selected Policy:', this.selectedPolicy);
      console.log('Initialized Form Data:', this.formData);
    },

    initializeFormData(policyName) {
      // Initialize formData based on the policy type
      switch(policyName) {
        case 'Liability cover':
          this.formData = {
            businessType: '',
            annualRevenue: null,
            employeeCount: null,
            claimsHistory: ''
          };
          break;
        case 'Life Cover':
          this.formData = {
            fullName: '',
            dateOfBirth: '',
            occupation: '',
            smoker: '',
            coverageAmount: null
          };
          break;
        case 'Health Policy':
          this.formData = {
            fullName: '',
            dateOfBirth: '',
            gender: '',
            weight: null,
            height: null,
            smoker: '',
            familyHistory: '',
            currentConditions: []
          };
          break;
        case 'Car Policy':
          this.formData = {
            carMake: '',
            carModel: '',
            carYear: null,
            licensePlate: '',
            driverLicense: '',
            annualMileage: null,
            parkingLocation: '',
            previousClaims: ''
          };
          break;
        default:
          this.formData = {};
      }
    },

    loadDraftData() {
      const draftKey = `${this.userId}_${this.selectedPolicy.id}_draft`;
      const savedData = localStorage.getItem(draftKey);
      if (savedData) {
        // Merge saved data with initialized formData
        this.formData = { ...this.formData, ...JSON.parse(savedData) };
      }
    },

    saveAsDraft() {
      const draftKey = `${this.userId}_${this.selectedPolicy.id}_draft`;
      localStorage.setItem(draftKey, JSON.stringify(this.formData));
      alert('Draft saved successfully!');
    },

    calculatePremium() {
      let premium = this.selectedPolicy.premium;

      switch (this.selectedPolicy.policyName) {
        case 'Liability cover':
          premium += this.formData.annualRevenue > 1000000 ? 10000 : 5000;
          premium += this.formData.employeeCount > 50 ? 5000 : 2000;
          premium += this.formData.claimsHistory === 'Yes' ? 8000 : 0;
          break;
        case 'Life Cover':
          const age = new Date().getFullYear() - new Date(this.formData.dateOfBirth).getFullYear();
          premium += age > 50 ? 10000 : 5000;
          premium += this.formData.smoker === 'Yes' ? 15000 : 0;
          premium += (this.formData.coverageAmount / 1000000) * 2000;
          break;
        case 'Health Policy':
          const bmi = this.formData.weight / ((this.formData.height / 100) ** 2);
          premium += bmi > 30 ? 15000 : bmi > 25 ? 8000 : 0;
          premium += this.formData.smoker === 'Yes' ? 20000 : 0;
          premium += this.formData.currentConditions.length * 5000;
          break;
        case 'Car Policy':
          premium += parseInt(this.formData.carYear) < 2010 ? 8000 : 3000;
          premium += this.formData.annualMileage > 20000 ? 5000 : 2000;
          premium += this.formData.previousClaims === 'Yes' ? 10000 : 0;
          premium += this.formData.parkingLocation === 'Street' ? 5000 : 0;
          break;
      }

      return premium;
    },

    generatePDF() {
      const doc = new jsPDF();
      doc.text(`${this.selectedPolicy.policyName} Subscription Details`, 10, 10);
      
      const tableData = Object.entries(this.formData).map(([key, value]) => {
        if (Array.isArray(value)) {
          return [key, value.join(', ')];
        }
        return [key, value];
      });

      doc.autoTable({
        head: [['Field', 'Value']],
        body: tableData,
        startY: 20,
      });

      const premium = this.calculatePremium();
      doc.text(`Calculated Premium: ${this.formatCurrency(premium)} MWK`, 10, doc.lastAutoTable.finalY + 10);

      doc.save(`${this.selectedPolicy.policyName}_subscription.pdf`);
    },

    async submitForm(paymentMethod) {
      this.isLoading = true;
      const premium = this.calculatePremium();
      
      try {
        let response;
        if (paymentMethod === 'stripe') {
          response = await this.createStripeCheckoutSession(premium);
        } else if (paymentMethod === 'paypal') {
          const usdAmount = this.convertMWKtoUSD(premium);
          response = await this.createPayPalOrder(usdAmount);
        }

        if (response.data && response.data.checkout_url) {
          window.location.href = response.data.checkout_url;
        } else {
          console.error('No checkout URL received from the server');
        }
      } catch (error) {
        console.error(`Error creating ${paymentMethod} checkout session:`, error);
        // Handle the error (e.g., show an error message to the user)
      } finally {
        this.isLoading = false;
      }
    },

    async createStripeCheckoutSession(premium) {
      return await axios.post(`${import.meta.env.VITE_APP_API_URL}/api/v1/pay`, {
        paymentMethod: 'stripe',
        items: [{
          price_data: {
            currency: 'mwk',
            product_data: {
              name: this.selectedPolicy.policyName,
              images: [this.selectedPolicy.image],
            },
            unit_amount: premium * 100, // Convert to cents
          },
          quantity: 1,
        }],
        metadata: {
          customerName: localStorage.getItem('userName'),
          customerEmail: localStorage.getItem('userEmail'),
          customerId: localStorage.getItem('userId'),
          successUrl: `${window.location.origin}/payment-success`,
          cancelUrl: `${window.location.origin}/payment-cancel`,
        }
      });
    },

    async createPayPalOrder(usdAmount) {
      return await axios.post(`${import.meta.env.VITE_APP_API_URL}/api/v1/pay`, {
        paymentMethod: 'paypal',
        amount: usdAmount,
        currency: 'USD',
        description: this.selectedPolicy.policyName,
        metadata: {
          customerName: localStorage.getItem('userName'),
          customerEmail: localStorage.getItem('userEmail'),
          customerId: localStorage.getItem('userId'),
          successUrl: `${window.location.origin}/payment-success`,
          cancelUrl: `${window.location.origin}/payment-cancel`,
        }
      });
    },

    convertMWKtoUSD(mwkAmount) {
      // Implement currency conversion here
      // You might want to use a fixed exchange rate or fetch the current rate from an API
      const exchangeRate = 0.00098; // Example rate: 1 MWK = 0.00098 USD
      return (mwkAmount * exchangeRate).toFixed(2);
    },

    closeModal() {
      this.showModal = false;
      this.selectedPolicy = null;
      this.formData = {};
    },
  },
};
</script>

<style scoped>
.vue-multiselect {
  @apply p-2 border rounded;
}
</style>