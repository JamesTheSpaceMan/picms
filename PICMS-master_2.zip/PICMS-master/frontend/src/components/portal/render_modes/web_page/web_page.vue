
<template>
    <WidgetRenderer :widgets="resource.widgets" />
</template>
<script>
import WidgetRenderer from '../../../widgets/widget_renderer.vue';
export default {
    components: {
        WidgetRenderer
    },
    props: {
        resource: {
            type: Object,
            required: true,
        },
    }
}
</script>